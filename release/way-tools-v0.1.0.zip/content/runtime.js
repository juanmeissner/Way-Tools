(() => {
  "use strict";

  const registry = globalThis.WAY_TOOLS_SCRIPTS || [];
  const scriptsById = new Map(registry.map((script) => [script.id, script]));
  const storageSnapshotPromise = chrome.storage.local.get(null).catch((error) => {
    console.error("[Way Tools] Não foi possível carregar o armazenamento:", error);
    return {};
  });

  function enabledKey(scriptId) {
    return `wayTools.scripts.${scriptId}.enabled`;
  }

  function dataKey(scriptId, key) {
    return `wayTools.data.${scriptId}.${key}`;
  }

  function hasOwn(object, key) {
    return Object.prototype.hasOwnProperty.call(object, key);
  }

  let writeQueue = Promise.resolve();

  globalThis.WayToolsRuntime = Object.freeze({
    async run(scriptId, start) {
      const definition = scriptsById.get(scriptId);

      if (!definition) {
        console.error(`[Way Tools] Script não cadastrado: ${scriptId}`);
        return;
      }

      const snapshot = await storageSnapshotPromise;
      const configuredValue = snapshot[enabledKey(scriptId)];
      const isEnabled = configuredValue === undefined
        ? definition.defaultEnabled !== false
        : configuredValue === true;

      if (!isEnabled) {
        console.info(`[Way Tools] ${definition.name} está desativado.`);
        return;
      }

      const storage = Object.freeze({
        getValue(key, fallbackValue) {
          const namespacedKey = dataKey(scriptId, key);
          return hasOwn(snapshot, namespacedKey)
            ? snapshot[namespacedKey]
            : fallbackValue;
        },

        setValue(key, value) {
          const namespacedKey = dataKey(scriptId, key);
          snapshot[namespacedKey] = value;

          writeQueue = writeQueue
            .then(() => chrome.storage.local.set({ [namespacedKey]: value }))
            .catch((error) => {
              console.error(`[Way Tools] Falha ao salvar dados de ${definition.name}:`, error);
            });

          return value;
        }
      });

      try {
        start(storage);
        console.info(`[Way Tools] ${definition.name} v${definition.version} iniciado.`);
      } catch (error) {
        console.error(`[Way Tools] Falha ao iniciar ${definition.name}:`, error);
      }
    }
  });
})();

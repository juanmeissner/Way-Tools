(() => {
  "use strict";

  globalThis.WAY_TOOLS_SCRIPTS = Object.freeze([
    Object.freeze({
      id: "way-mensagens",
      name: "Mensagens Personalizadas",
      version: "3.4",
      description: "Mensagens, autocomplete, dados do cliente, visitas técnicas e alertas de inatividade.",
      matches: Object.freeze(["https://ia-nocodb.internetway.com.br/*"]),
      defaultEnabled: true
    })
  ]);
})();

/*
 * Way Tools - ERP Interface Compacta v3.4
 * Interface compacta exclusiva do ERP Way.
 */

globalThis.WayToolsRuntime.run("way-interface-compacta", (storage) => {
    "use strict";

    const GM_getValue = storage.getValue;
    const GM_setValue = storage.setValue;
    const GM_registerMenuCommand = (label, callback) =>
        globalThis.WayToolsRuntime.registerMenuCommand("way-interface-compacta", label, callback);
// ==UserScript==
// @name         Way ERP - Interface Compacta
// @namespace    way-interface
// @version      3.4
// @description  Interface compacta com resumo, cópia rica e visita técnica com rascunho isolado por atendimento
// @match        https://erp.internetway.com.br/*
// @run-at       document-start
// @grant        GM_registerMenuCommand
// @grant        GM_getValue
// @grant        GM_setValue
// ==/UserScript==

(function () {
    'use strict';


    /* =========================================================
       CONFIGURAÇÕES
       ========================================================= */

    const CONFIG = {
        alturaCampoMensagem: 82,
        tamanhoBotoesAcoes: 38,
        ocultarTags: true,
        removerImagemRodape: true,
        exibirResumoCliente: true
    };


    /* =========================================================
       PERÍODOS DA VISITA
       ========================================================= */

    const PERIODOS_VISITA = {

        manha: {
            nome: 'Manhã',
            inicio: '08:00',
            fim: '12:00'
        },

        tarde: {
            nome: 'Tarde',
            inicio: '13:00',
            fim: '17:00'
        },

        noite: {
            nome: 'Noite',
            inicio: '18:00',
            fim: '20:00'
        }
    };


    /* =========================================================
       POSIÇÃO DAS ABAS
       ========================================================= */

    const STORAGE_POSICAO_ABAS =
        'way-interface-posicao-abas';


    let POSICAO_ABAS =
        GM_getValue(
            STORAGE_POSICAO_ABAS,
            'topo'
        );


    /* =========================================================
       CACHE DA VISITA
       =========================================================

       IMPORTANTE:

       O cache usa sessionStorage.

       Isso significa:

       Atendimento 7028224:
       way-visita-tecnica-7028224

       Atendimento 7029000:
       way-visita-tecnica-7029000

       Cada atendimento tem seus próprios dados.

       Ao fechar a ABA DO NAVEGADOR, o sessionStorage
       normalmente é descartado.

       Nenhum dado de visita é armazenado via
       localStorage ou GM_setValue.
       ========================================================= */

    const CACHE_VISITA_PREFIXO =
        'way-visita-tecnica-';


    /* =========================================================
       SELETORES
       ========================================================= */

    const CLASSE_TAGS =
        '.atendimento-tags';

    const CLASSE_CABECALHO =
        '.cabecalho_msg';

    const SELETOR_RODAPE =
        'img[src*="/public/uploads/rodape.jpg"]';

    const SELETOR_ABAS =
        '#tabs';

    const SELETOR_CONTEUDO_ABAS =
        '#Abas';

    const SELETOR_ACOES =
        '.acoes-agente';


    /* =========================================================
       CSS
       ========================================================= */

    function adicionarCSS() {

        if (
            document.getElementById(
                'way-interface-css'
            )
        ) {
            return;
        }


        const style =
            document.createElement(
                'style'
            );


        style.id =
            'way-interface-css';


        style.textContent = `

            /* =================================================
               RESUMO DO CLIENTE
               ================================================= */

            .way-customer-summary {

                display: flex !important;
                align-items: center !important;
                flex-wrap: wrap !important;

                gap: 6px 14px !important;

                width: 100% !important;

                margin: 0 0 5px 0 !important;
                padding: 6px 8px !important;

                box-sizing: border-box !important;

                background:
                    var(
                        --way-bg-tertiary,
                        #f6f8fa
                    ) !important;

                border:
                    1px solid
                    var(
                        --way-border,
                        #d9dee5
                    ) !important;

                border-radius: 5px !important;

                color:
                    var(
                        --way-text,
                        #333
                    ) !important;

                font-size: 12px !important;
                line-height: 22px !important;

                clear: both !important;
            }


            .way-summary-item {

                display: inline-flex !important;
                align-items: center !important;

                gap: 4px !important;

                min-height: 24px !important;

                white-space: nowrap !important;
            }


            .way-summary-icon {

                display: inline-flex !important;

                align-items: center !important;
                justify-content: center !important;

                width: 18px !important;

                font-size: 14px !important;

                line-height: 1 !important;
            }


            .way-summary-label {

                color:
                    var(
                        --way-text,
                        #333
                    ) !important;

                font-weight: 700 !important;
            }


            .way-summary-value {

                color:
                    var(
                        --way-text,
                        #333
                    ) !important;

                font-weight: 700 !important;

                user-select: text !important;
            }


            /* =================================================
               AÇÕES DO RESUMO
               ================================================= */

            .way-summary-actions {

                display: inline-flex !important;

                align-items: center !important;

                gap: 6px !important;

                margin-left: auto !important;
            }


            /* =================================================
               BOTÃO DE CÓPIA INDIVIDUAL
               ================================================= */

            .way-summary-copy {

                display: inline-flex !important;

                align-items: center !important;
                justify-content: center !important;

                width: 24px !important;
                height: 24px !important;

                min-width: 24px !important;

                padding: 0 !important;

                margin: 0 0 0 2px !important;

                border:
                    1px solid
                    var(
                        --way-border,
                        #d0d5db
                    ) !important;

                border-radius: 4px !important;

                background:
                    var(
                        --way-surface,
                        #fff
                    ) !important;

                color:
                    var(
                        --way-text-secondary,
                        #555
                    ) !important;

                cursor: pointer !important;

                font-size: 12px !important;

                box-shadow: none !important;
            }


            .way-summary-copy:hover {

                background:
                    var(
                        --way-surface-hover,
                        #eceff2
                    ) !important;
            }


            /* =================================================
               BOTÕES PRINCIPAIS
               ================================================= */

            .way-copy-all,
            .way-technical-visit {

                display: inline-flex !important;

                align-items: center !important;
                justify-content: center !important;

                gap: 4px !important;

                min-height: 27px !important;

                padding: 3px 9px !important;

                margin: 0 !important;

                border:
                    1px solid
                    var(
                        --way-border,
                        #d0d5db
                    ) !important;

                border-radius: 4px !important;

                background:
                    var(
                        --way-surface,
                        #fff
                    ) !important;

                color:
                    var(
                        --way-text,
                        #333
                    ) !important;

                cursor: pointer !important;

                font-size: 11px !important;

                font-weight: 600 !important;

                box-shadow: none !important;
            }


            .way-copy-all:hover,
            .way-technical-visit:hover {

                background:
                    var(
                        --way-surface-hover,
                        #eceff2
                    ) !important;
            }


            .way-technical-visit {

                border-color:
                    var(
                        --way-primary,
                        #1687d9
                    ) !important;
            }


            /* =================================================
               CAMPOS ORIGINAIS
               ================================================= */

            .contato-nome.way-resumo-original-oculto,
            .contato-telefone.way-resumo-original-oculto,
            .atendimento-protocolo.way-resumo-original-oculto {

                display: none !important;
            }


            /* =================================================
               MODAL DE VISITA
               ================================================= */

            .way-visit-overlay {

                position: fixed !important;

                inset: 0 !important;

                z-index: 2147483646 !important;

                display: flex !important;

                align-items: center !important;
                justify-content: center !important;

                padding: 20px !important;

                background:
                    rgba(0, 0, 0, .62) !important;

                backdrop-filter:
                    blur(2px);
            }


            .way-visit-modal {

                width:
                    min(
                        760px,
                        calc(100vw - 30px)
                    ) !important;

                max-height:
                    calc(100vh - 40px) !important;

                display: flex !important;

                flex-direction: column !important;

                background:
                    var(
                        --way-bg-secondary,
                        #fff
                    ) !important;

                color:
                    var(
                        --way-text,
                        #222
                    ) !important;

                border:
                    1px solid
                    var(
                        --way-border,
                        #d4d9df
                    ) !important;

                border-radius: 10px !important;

                box-shadow:
                    0 18px 55px
                    rgba(0, 0, 0, .35) !important;

                overflow: hidden !important;
            }


            .way-visit-header {

                display: flex !important;

                align-items: center !important;
                justify-content: space-between !important;

                gap: 10px !important;

                padding: 12px 15px !important;

                background:
                    var(
                        --way-bg-tertiary,
                        #f5f7f9
                    ) !important;

                border-bottom:
                    1px solid
                    var(
                        --way-border,
                        #d4d9df
                    ) !important;
            }


            .way-visit-title {

                margin: 0 !important;

                color:
                    var(
                        --way-text,
                        #222
                    ) !important;

                font-size: 16px !important;

                font-weight: 700 !important;
            }


            .way-visit-close {

                width: 30px !important;
                height: 30px !important;

                padding: 0 !important;

                display: inline-flex !important;

                align-items: center !important;
                justify-content: center !important;

                background:
                    transparent !important;

                color:
                    var(
                        --way-text-secondary,
                        #666
                    ) !important;

                border:
                    1px solid transparent !important;

                border-radius: 5px !important;

                cursor: pointer !important;

                font-size: 21px !important;

                line-height: 1 !important;
            }


            .way-visit-close:hover {

                background:
                    var(
                        --way-surface-hover,
                        #eceff2
                    ) !important;

                border-color:
                    var(
                        --way-border,
                        #d4d9df
                    ) !important;
            }


            .way-visit-body {

                padding: 14px !important;

                overflow-y: auto !important;
            }


            .way-visit-grid {

                display: grid !important;

                grid-template-columns:
                    repeat(
                        2,
                        minmax(
                            0,
                            1fr
                        )
                    ) !important;

                gap: 11px 14px !important;
            }


            .way-visit-field {

                display: flex !important;

                flex-direction: column !important;

                gap: 5px !important;
            }


            .way-visit-field-full {

                grid-column:
                    1 / -1 !important;
            }


            .way-visit-field label {

                margin: 0 !important;

                color:
                    var(
                        --way-text,
                        #222
                    ) !important;

                font-size: 12px !important;

                font-weight: 700 !important;
            }


            .way-visit-field input,
            .way-visit-field select,
            .way-visit-field textarea {

                width: 100% !important;

                box-sizing:
                    border-box !important;

                padding:
                    7px 9px !important;

                background:
                    var(
                        --way-input-bg,
                        #fff
                    ) !important;

                color:
                    var(
                        --way-input-text,
                        #222
                    ) !important;

                border:
                    1px solid
                    var(
                        --way-border,
                        #ccd2d8
                    ) !important;

                border-radius: 5px !important;

                outline: none !important;

                font-family:
                    inherit !important;

                font-size: 12px !important;
            }


            .way-visit-field input:focus,
            .way-visit-field select:focus,
            .way-visit-field textarea:focus {

                border-color:
                    var(
                        --way-primary,
                        #1687d9
                    ) !important;

                box-shadow:
                    0 0 0 1px
                    var(
                        --way-primary,
                        #1687d9
                    ) !important;
            }


            .way-visit-preview {

                min-height: 320px !important;

                resize: vertical !important;

                white-space: pre-wrap !important;

                line-height: 1.45 !important;
            }


            .way-visit-cache-info {

                display: flex !important;

                align-items: center !important;

                gap: 5px !important;

                margin: 0 0 8px 0 !important;

                padding: 6px 8px !important;

                background:
                    var(
                        --way-bg-tertiary,
                        #f5f7f9
                    ) !important;

                color:
                    var(
                        --way-text-secondary,
                        #666
                    ) !important;

                border:
                    1px solid
                    var(
                        --way-border-soft,
                        #e1e5e9
                    ) !important;

                border-radius: 5px !important;

                font-size: 11px !important;
            }


            .way-visit-status {

                min-height: 18px !important;

                margin: 8px 0 0 0 !important;

                color:
                    var(
                        --way-text-secondary,
                        #666
                    ) !important;

                font-size: 11px !important;
            }


            .way-visit-status.success {

                color:
                    #2e8b57 !important;
            }


            .way-visit-status.error {

                color:
                    #d9534f !important;
            }


            .way-visit-footer {

                display: flex !important;

                align-items: center !important;
                justify-content: flex-end !important;

                gap: 8px !important;

                padding: 11px 14px !important;

                background:
                    var(
                        --way-bg-tertiary,
                        #f5f7f9
                    ) !important;

                border-top:
                    1px solid
                    var(
                        --way-border,
                        #d4d9df
                    ) !important;
            }


            .way-visit-footer button {

                min-height: 31px !important;

                padding: 5px 12px !important;

                border-radius: 5px !important;

                cursor: pointer !important;

                font-size: 12px !important;

                font-weight: 600 !important;
            }


            .way-visit-clear {

                margin-right: auto !important;

                background:
                    transparent !important;

                color:
                    #d9534f !important;

                border:
                    1px solid
                    rgba(
                        217,
                        83,
                        79,
                        .5
                    ) !important;
            }


            .way-visit-clear:hover {

                background:
                    rgba(
                        217,
                        83,
                        79,
                        .08
                    ) !important;
            }


            .way-visit-cancel {

                background:
                    var(
                        --way-surface,
                        #fff
                    ) !important;

                color:
                    var(
                        --way-text,
                        #333
                    ) !important;

                border:
                    1px solid
                    var(
                        --way-border,
                        #ccd2d8
                    ) !important;
            }


            .way-visit-copy {

                background:
                    var(
                        --way-primary,
                        #1687d9
                    ) !important;

                color:
                    #fff !important;

                border:
                    1px solid
                    var(
                        --way-primary,
                        #1687d9
                    ) !important;
            }


            .way-visit-copy:hover {

                filter:
                    brightness(.94);
            }


            @media (
                max-width: 650px
            ) {

                .way-visit-grid {

                    grid-template-columns:
                        1fr !important;
                }


                .way-visit-field-full {

                    grid-column:
                        auto !important;
                }


                .way-visit-footer {

                    flex-wrap:
                        wrap !important;
                }


                .way-visit-clear {

                    width:
                        100% !important;

                    margin-right:
                        0 !important;
                }
            }


            /* =================================================
               TAGS
               ================================================= */

            .atendimento-tags.way-tags-ocultas {

                display: none !important;
            }


            img[src*="/public/uploads/rodape.jpg"] {

                display: none !important;
            }


            .way-toggle-tags {

                display: inline-flex !important;

                align-items: center !important;
                justify-content: center !important;

                gap: 4px !important;

                padding: 2px 7px !important;

                margin: 0 4px 2px 0 !important;

                border:
                    1px solid
                    var(
                        --way-border,
                        #d5d5d5
                    ) !important;

                border-radius: 4px !important;

                background:
                    var(
                        --way-surface,
                        #fff
                    ) !important;

                color:
                    var(
                        --way-text-secondary,
                        #666
                    ) !important;

                font-size: 11px !important;

                line-height: 18px !important;

                cursor: pointer !important;

                float: right !important;
            }


            .way-toggle-tags:hover {

                background:
                    var(
                        --way-surface-hover,
                        #f5f5f5
                    ) !important;
            }


            .way-toggle-tags.way-tags-abertas {

                font-weight: 600 !important;
            }


            /* =================================================
               CHAT
               ================================================= */

            .conversa > .slimScrollDiv,
            .conversa .slimScrollDiv.scroll-active {

                padding-bottom: 4px !important;
            }


            .conversa .messages i.fa,
            .conversa .messages i.fas,
            .conversa .messages i.far,
            .conversa .messages i.fab,
            .conversa .messages i.fa-solid,
            .conversa .messages i.fa-regular,
            .conversa .scroll-button i,
            .conversa .msg-responder i,
            .conversa .header-msg-responder i,
            .conversa .label-tools i,
            .conversa span[rel="tooltip"] > i {

                display: inline-block !important;

                visibility: visible !important;

                opacity: 1 !important;

                width: auto !important;
                height: auto !important;

                min-width: 0 !important;
                min-height: 0 !important;

                max-width: none !important;
                max-height: none !important;

                margin: 0 !important;
                padding: 0 !important;

                line-height: normal !important;

                vertical-align: baseline !important;

                transform: none !important;

                overflow: visible !important;
            }


            .conversa .messages i::before,
            .conversa .scroll-button i::before,
            .conversa .msg-responder i::before,
            .conversa .label-tools i::before,
            .conversa span[rel="tooltip"] > i::before {

                display: inline-block !important;

                visibility: visible !important;

                opacity: 1 !important;
            }


            .conversa .messages-input-form {

                margin-top: 0 !important;
                margin-bottom: 0 !important;

                padding-top: 0 !important;
                padding-bottom: 0 !important;
            }


            .conversa .messages-input-form form {

                margin: 0 !important;
                padding: 0 !important;
            }


            .conversa
            .messages-input-form
            .faketextbox[contenteditable="true"] {

                height:
                    ${CONFIG.alturaCampoMensagem}px !important;

                min-height:
                    ${CONFIG.alturaCampoMensagem}px !important;

                max-height: 120px !important;

                overflow-y: auto !important;

                box-sizing: border-box !important;
            }


            .conversa
            .messages-input-form
            textarea {

                height:
                    ${CONFIG.alturaCampoMensagem}px !important;

                min-height:
                    ${CONFIG.alturaCampoMensagem}px !important;

                max-height: 120px !important;

                box-sizing: border-box !important;
            }


            .conversa .group-msg {

                display: flex !important;

                align-items: flex-end !important;

                gap: 4px !important;
            }


            .conversa .group-msg .input {

                margin-right: 0 !important;
            }


            .conversa
            .messages-input-form
            .hsm_buttons {

                margin: 0 3px 3px 0 !important;

                padding: 0 !important;
            }


            .conversa
            .messages-input-form
            .hsm_buttons > a {

                display: inline-flex !important;

                align-items: center !important;
                justify-content: center !important;

                margin: 0 3px !important;

                padding: 2px !important;

                font-size: 15px !important;

                line-height: 1 !important;
            }


            .conversa
            .messages-input-form
            .hsm_buttons > a > i {

                display: inline-block !important;

                visibility: visible !important;

                opacity: 1 !important;

                width: auto !important;
                height: auto !important;

                margin: 0 !important;
                padding: 0 !important;

                line-height: 1 !important;
            }


            .conversa
            .messages-input-form
            .buttons {

                display: flex !important;

                align-items: flex-end !important;

                margin: 0 !important;
                padding: 0 !important;
            }


            .conversa
            .messages-input-form
            button[data-rel="enviarMsg"] {

                width: 36px !important;
                min-width: 36px !important;

                height: 36px !important;
                min-height: 36px !important;

                padding: 0 !important;

                margin: 0 0 2px 0 !important;

                display: inline-flex !important;

                align-items: center !important;
                justify-content: center !important;

                line-height: 1 !important;

                box-sizing: border-box !important;
            }


            .conversa
            .messages-input-form
            button[data-rel="enviarMsg"] > i {

                display: inline-block !important;

                visibility: visible !important;

                opacity: 1 !important;

                width: auto !important;
                height: auto !important;

                margin: 0 !important;
                padding: 0 !important;

                line-height: 1 !important;
            }


            .conversa div:has(
                > b[data-limit-caracter]
            ),

            .conversa div:has(
                > b[data-total-caracter]
            ) {

                font-size: 10px !important;

                line-height: 12px !important;

                min-height: 12px !important;

                margin: 1px 2px 0 0 !important;

                padding: 0 !important;

                text-align: right !important;

                color: #999 !important;
            }


            .way-gap-acoes {

                display: none !important;
            }


            /* =================================================
               BOTÕES INFERIORES
               ================================================= */

            .acoes-agente {

                display: flex !important;

                justify-content: center !important;
                align-items: center !important;

                flex-wrap: wrap !important;

                gap: 6px !important;

                margin: 3px 0 0 0 !important;

                padding: 0 !important;

                min-height:
                    ${CONFIG.tamanhoBotoesAcoes}px !important;
            }


            .acoes-agente
            > .btn.btn-circle.btn-xlarge {

                width:
                    ${CONFIG.tamanhoBotoesAcoes}px !important;

                min-width:
                    ${CONFIG.tamanhoBotoesAcoes}px !important;

                max-width:
                    ${CONFIG.tamanhoBotoesAcoes}px !important;

                height:
                    ${CONFIG.tamanhoBotoesAcoes}px !important;

                min-height:
                    ${CONFIG.tamanhoBotoesAcoes}px !important;

                max-height:
                    ${CONFIG.tamanhoBotoesAcoes}px !important;

                display: inline-flex !important;

                align-items: center !important;
                justify-content: center !important;

                padding: 0 !important;
                margin: 0 !important;

                line-height: 1 !important;

                font-size: 15px !important;

                border-radius: 50% !important;

                box-sizing: border-box !important;
            }


            .acoes-agente
            > .btn.btn-circle.btn-xlarge
            > i {

                display: inline-flex !important;

                align-items: center !important;
                justify-content: center !important;

                width: 100% !important;
                height: 100% !important;

                margin: 0 !important;
                padding: 0 !important;

                line-height: 1 !important;

                position: static !important;

                transform: none !important;

                visibility: visible !important;

                opacity: 1 !important;
            }


            .acoes-agente
            > .btn.btn-circle.btn-xlarge
            > i::before {

                display: inline-block !important;

                visibility: visible !important;

                opacity: 1 !important;

                margin: 0 !important;
                padding: 0 !important;

                line-height: 1 !important;
            }


            /* =================================================
               ABAS
               ================================================= */

            .tabbable.way-layout-tabs-bottom {

                display: flex !important;

                flex-direction: column !important;

                width: 100% !important;
            }


            .tabbable.way-layout-tabs-bottom
            > #Abas {

                order: 10 !important;

                width: 100% !important;
            }


            .tabbable.way-layout-tabs-bottom
            > #tabs {

                order: 20 !important;

                width: 100% !important;

                margin: 5px 0 0 0 !important;

                padding: 0 !important;

                flex-shrink: 0 !important;
            }


            .tabbable.way-layout-tabs-bottom
            > #search-extras {

                order: 0 !important;
            }


            #tabs.way-tabs-bottom {

                width: 100% !important;

                clear: both !important;
            }


            #tabs.way-tabs-bottom > li {

                margin-bottom: 0 !important;
            }


            #tabs.way-tabs-bottom > li > a {

                margin-top: 0 !important;
                margin-bottom: 0 !important;
            }


            #Abas .tab-pane {

                margin-bottom: 0 !important;
                padding-bottom: 0 !important;
            }

        `;


        document.documentElement
            .appendChild(
                style
            );
    }


    /* =========================================================
       EXTRAI VALOR
       ========================================================= */

    function extrairValorCampo(
        cabecalho,
        seletor,
        rotulo
    ) {

        const elemento =
            cabecalho.querySelector(
                seletor
            );


        if (!elemento) {
            return '';
        }


        const clone =
            elemento.cloneNode(
                true
            );


        clone
            .querySelectorAll(
                [
                    'i',
                    'button',
                    '.fa',
                    '.fas',
                    '.far',
                    '.fab',
                    '.fa-solid',
                    '.fa-regular',
                    '[rel="tooltip"]',
                    '[data-toggle="tooltip"]'
                ].join(',')
            )
            .forEach(
                elementoExtra => {

                    elementoExtra.remove();
                }
            );


        let texto =
            clone.textContent ||
            '';


        texto =
            texto
                .replace(
                    /\s+/g,
                    ' '
                )
                .trim();


        texto =
            texto.replace(
                rotulo,
                ''
            );


        return texto.trim();
    }


    /* =========================================================
       LIMPA NOME
       ========================================================= */

    function limparNomeCliente(
        nome
    ) {

        if (!nome) {
            return '';
        }


        return String(
            nome
        )
            .replace(
                /\uFFFD/g,
                ''
            )
            .replace(
                /\s+\?+\s*$/,
                ''
            )
            .replace(
                /\s+/g,
                ' '
            )
            .trim();
    }


    /* =========================================================
       FORMATA TELEFONE
       ========================================================= */

    function formatarTelefone(
        telefone
    ) {

        if (!telefone) {
            return '';
        }


        let numeros =
            String(
                telefone
            )
                .replace(
                    /\D/g,
                    ''
                );


        if (
            numeros.startsWith('55') &&
            (
                numeros.length === 12 ||
                numeros.length === 13
            )
        ) {

            numeros =
                numeros.substring(2);
        }


        if (
            numeros.length === 11
        ) {

            return (
                '(' +
                numeros.substring(0, 2) +
                ') ' +
                numeros.substring(2, 7) +
                '-' +
                numeros.substring(7)
            );
        }


        if (
            numeros.length === 10
        ) {

            return (
                '(' +
                numeros.substring(0, 2) +
                ') ' +
                numeros.substring(2, 6) +
                '-' +
                numeros.substring(6)
            );
        }


        return telefone;
    }


    /* =========================================================
       ESCAPA HTML
       ========================================================= */

    function escaparHTML(
        texto
    ) {

        return String(
            texto ?? ''
        )
            .replace(
                /&/g,
                '&amp;'
            )
            .replace(
                /</g,
                '&lt;'
            )
            .replace(
                />/g,
                '&gt;'
            )
            .replace(
                /"/g,
                '&quot;'
            )
            .replace(
                /'/g,
                '&#039;'
            );
    }


    /* =========================================================
       CÓPIA SIMPLES
       ========================================================= */

    async function copiarTextoSimples(
        texto
    ) {

        texto =
            String(
                texto ?? ''
            );


        try {

            await navigator
                .clipboard
                .writeText(
                    texto
                );


            return true;

        } catch (erro) {
        }


        try {

            const textarea =
                document.createElement(
                    'textarea'
                );


            textarea.value =
                texto;


            textarea.setAttribute(
                'readonly',
                ''
            );


            textarea.style.position =
                'fixed';


            textarea.style.left =
                '-9999px';


            document.body.appendChild(
                textarea
            );


            textarea.focus();

            textarea.select();


            const sucesso =
                document.execCommand(
                    'copy'
                );


            textarea.remove();


            return sucesso;

        } catch (erro) {

            return false;
        }
    }


    /* =========================================================
       CÓPIA RICA
       ========================================================= */

    async function copiarConteudoRico(
        textoPlano,
        html
    ) {

        if (
            navigator.clipboard &&
            navigator.clipboard.write &&
            typeof ClipboardItem !==
                'undefined'
        ) {

            try {

                const item =
                    new ClipboardItem(
                        {
                            'text/plain':
                                new Blob(
                                    [
                                        textoPlano
                                    ],
                                    {
                                        type:
                                            'text/plain'
                                    }
                                ),

                            'text/html':
                                new Blob(
                                    [
                                        html
                                    ],
                                    {
                                        type:
                                            'text/html'
                                    }
                                )
                        }
                    );


                await navigator
                    .clipboard
                    .write(
                        [
                            item
                        ]
                    );


                return true;

            } catch (erro) {

                console.warn(
                    '[Way Interface] Clipboard HTML indisponível.',
                    erro
                );
            }
        }


        return copiarTextoSimples(
            textoPlano
        );
    }


    /* =========================================================
       FEEDBACK
       ========================================================= */

    function mostrarFeedbackCopia(
        botao
    ) {

        if (!botao) {
            return;
        }


        const original =
            botao.innerHTML;


        botao.innerHTML =
            '✓';


        setTimeout(
            function () {

                botao.innerHTML =
                    original;
            },

            800
        );
    }


    /* =========================================================
       DATA ATUAL
       ========================================================= */

    function obterDataHojeInput() {

        const hoje =
            new Date();


        const ano =
            hoje.getFullYear();


        const mes =
            String(
                hoje.getMonth() + 1
            ).padStart(
                2,
                '0'
            );


        const dia =
            String(
                hoje.getDate()
            ).padStart(
                2,
                '0'
            );


        return (
            `${ano}-${mes}-${dia}`
        );
    }


    /* =========================================================
       FORMATA DATA
       ========================================================= */

    function formatarDataVisita(
        valor
    ) {

        if (!valor) {
            return '';
        }


        const partes =
            valor.split(
                '-'
            );


        if (
            partes.length !== 3
        ) {

            return '';
        }


        const ano =
            Number(
                partes[0]
            );


        const mes =
            Number(
                partes[1]
            );


        const dia =
            Number(
                partes[2]
            );


        const data =
            new Date(
                ano,
                mes - 1,
                dia
            );


        if (
            Number.isNaN(
                data.getTime()
            )
        ) {

            return '';
        }


        const diasSemana = [
            'Domingo',
            'Segunda-Feira',
            'Terça-Feira',
            'Quarta-Feira',
            'Quinta-Feira',
            'Sexta-Feira',
            'Sábado'
        ];


        const nomeDia =
            diasSemana[
                data.getDay()
            ];


        const dataFormatada =
            String(
                dia
            ).padStart(
                2,
                '0'
            ) +
            '/' +
            String(
                mes
            ).padStart(
                2,
                '0'
            ) +
            '/' +
            ano;


        return (
            nomeDia +
            ' ' +
            dataFormatada
        );
    }


    /* =========================================================
       IDENTIFICA O ATENDIMENTO
       ========================================================= */

    function obterCodigoAtendimento(
        cabecalho
    ) {

        if (!cabecalho) {
            return '';
        }


        const pane =
            cabecalho.closest(
                '.tab-pane[id^="aba-"]'
            );


        if (!pane) {
            return '';
        }


        const codigo =
            pane.id.replace(
                /^aba-/,
                ''
            );


        /*
         * Aceita apenas números.
         *
         * Caso o código não seja confiável,
         * o cache simplesmente não será usado.
         */

        if (
            !/^\d+$/.test(
                codigo
            )
        ) {

            return '';
        }


        return codigo;
    }


    /* =========================================================
       CHAVE DO CACHE
       ========================================================= */

    function obterChaveCacheVisita(
        codigoAtendimento
    ) {

        if (
            !codigoAtendimento
        ) {

            return '';
        }


        return (
            CACHE_VISITA_PREFIXO +
            codigoAtendimento
        );
    }


    /* =========================================================
       CARREGA CACHE
       ========================================================= */

    function carregarCacheVisita(
        codigoAtendimento
    ) {

        const chave =
            obterChaveCacheVisita(
                codigoAtendimento
            );


        if (!chave) {

            return null;
        }


        try {

            const valor =
                sessionStorage.getItem(
                    chave
                );


            if (!valor) {

                return null;
            }


            const dados =
                JSON.parse(
                    valor
                );


            if (
                !dados ||
                typeof dados !==
                    'object' ||
                Array.isArray(
                    dados
                )
            ) {

                return null;
            }


            return dados;

        } catch (erro) {

            console.warn(
                '[Way Interface] Não foi possível carregar o rascunho da visita.',
                erro
            );


            return null;
        }
    }


    /* =========================================================
       SALVA CACHE
       ========================================================= */

    function salvarCacheVisita(
        codigoAtendimento,
        dados
    ) {

        const chave =
            obterChaveCacheVisita(
                codigoAtendimento
            );


        /*
         * Segurança:
         *
         * Sem ID de atendimento confiável,
         * NADA é armazenado.
         */

        if (!chave) {

            return false;
        }


        try {

            const cache = {

                nome:
                    String(
                        dados.nome ||
                        ''
                    ),

                telefone:
                    String(
                        dados.telefone ||
                        ''
                    ),

                endereco:
                    String(
                        dados.endereco ||
                        ''
                    ),

                data:
                    String(
                        dados.data ||
                        ''
                    ),

                periodo:
                    String(
                        dados.periodo ||
                        ''
                    ),

                protocolo:
                    String(
                        dados.protocolo ||
                        ''
                    ),

                /*
                 * Apenas informativo.
                 */

                atualizadoEm:
                    Date.now()
            };


            sessionStorage.setItem(
                chave,
                JSON.stringify(
                    cache
                )
            );


            return true;

        } catch (erro) {

            console.warn(
                '[Way Interface] Não foi possível salvar o rascunho da visita.',
                erro
            );


            return false;
        }
    }


    /* =========================================================
       APAGA CACHE DE UM ATENDIMENTO
       ========================================================= */

    function apagarCacheVisita(
        codigoAtendimento
    ) {

        const chave =
            obterChaveCacheVisita(
                codigoAtendimento
            );


        if (!chave) {

            return false;
        }


        try {

            sessionStorage.removeItem(
                chave
            );


            return true;

        } catch (erro) {

            return false;
        }
    }


    /* =========================================================
       GERA TEXTO DA VISITA
       ========================================================= */

    function gerarTextoVisita(
        dados
    ) {

        const periodo =
            PERIODOS_VISITA[
                dados.periodo
            ];


        const dia =
            formatarDataVisita(
                dados.data
            );


        const horario =
            periodo
                ?
                `das *${periodo.inicio}h às ${periodo.fim}h*`
                :
                '';


        return `✅ *Visita Técnica Agendada com Sucesso*

👤 *Nome:* ${dados.nome}
📍 *Endereço:* ${dados.endereco}
📅 *Dia:* ${dia}
🌤️ *Período:* ${periodo?.nome || ''}
📱 *Telefone:* ${dados.telefone}
🕐 *Previsão de atendimento:* ${horario}
🔢 *Protocolo:* *${dados.protocolo}*

📲 *Confirmação da visita*
O setor de agendamento enviará uma mensagem via *WhatsApp* para confirmar a visita. *É importante responder à mensagem* para que o agendamento seja validado.

🚗 *Deslocamento do técnico*
Assim que o técnico iniciar o deslocamento até o endereço, você receberá um *SMS* com a *placa e os dados do veículo* do profissional responsável pela execução da ordem de serviço.

⚠️ *Importante:*
É necessário que haja *uma pessoa maior de 18 anos no local* para receber o técnico.

🔄 *Precisa reagendar?*
Caso não possa receber o técnico no período agendado, basta responder à mensagem de confirmação enviada pelo WhatsApp solicitando um novo horário ou entrar em contato com nossa equipe.

Estamos à disposição e teremos prazer em atendê-lo! 😊`;
    }


    /* =========================================================
       FECHA MODAL
       ========================================================= */

    function fecharModalVisita() {

        document
            .querySelector(
                '.way-visit-overlay'
            )
            ?.remove();
    }


    /* =========================================================
       ABRE MODAL
       ========================================================= */

    function abrirModalVisita(
        cabecalho,
        resumo
    ) {

        /*
         * Remove apenas a interface do modal anterior.
         *
         * O rascunho permanece no sessionStorage,
         * vinculado ao atendimento correto.
         */

        fecharModalVisita();


        /* =====================================================
           ID DO ATENDIMENTO
           ===================================================== */

        const codigoAtendimento =
            obterCodigoAtendimento(
                cabecalho
            );


        /* =====================================================
           DADOS ATUAIS DO CABEÇALHO
           ===================================================== */

        const nomeAtual =
            resumo
                .querySelector(
                    '[data-way-value="nome"]'
                )
                ?.textContent
                .trim()
            ||
            '';


        const telefoneAtual =
            resumo
                .querySelector(
                    '[data-way-value="telefone"]'
                )
                ?.textContent
                .trim()
            ||
            '';


        /* =====================================================
           CACHE EXCLUSIVO DESTE ATENDIMENTO
           ===================================================== */

        const cache =
            carregarCacheVisita(
                codigoAtendimento
            );


        /*
         * Se existir cache deste atendimento:
         *
         * usa o que foi digitado anteriormente.
         *
         * Se NÃO existir:
         *
         * Nome = cliente atual
         * Telefone = cliente atual
         * Endereço = vazio
         * Data = hoje
         * Período = vazio
         * Protocolo = vazio
         */

        const valoresIniciais = {

            nome:
                cache
                    ? cache.nome ?? nomeAtual
                    : nomeAtual,

            telefone:
                cache
                    ? cache.telefone ?? telefoneAtual
                    : telefoneAtual,

            endereco:
                cache
                    ? cache.endereco ?? ''
                    : '',

            data:
                cache
                    ? cache.data || obterDataHojeInput()
                    : obterDataHojeInput(),

            periodo:
                cache
                    ? cache.periodo ?? ''
                    : '',

            protocolo:
                cache
                    ? cache.protocolo ?? ''
                    : ''
        };


        /* =====================================================
           OVERLAY
           ===================================================== */

        const overlay =
            document.createElement(
                'div'
            );


        overlay.className =
            'way-visit-overlay';


        /* =====================================================
           MODAL
           ===================================================== */

        const modal =
            document.createElement(
                'div'
            );


        modal.className =
            'way-visit-modal';


        modal.innerHTML = `

            <div class="way-visit-header">

                <h3 class="way-visit-title">
                    🛠 Visita Técnica
                </h3>

                <button
                    type="button"
                    class="way-visit-close"
                    title="Fechar"
                >
                    ×
                </button>

            </div>


            <div class="way-visit-body">

                <div class="way-visit-cache-info">

                    💾

                    <span>
                        ${
                            codigoAtendimento
                                ?
                                `Rascunho exclusivo do atendimento ${escaparHTML(codigoAtendimento)}.`
                                :
                                'Atendimento não identificado: o rascunho não será armazenado.'
                        }
                    </span>

                </div>


                <div class="way-visit-grid">


                    <!-- NOME -->

                    <div class="way-visit-field">

                        <label>
                            👤 Nome
                        </label>

                        <input
                            type="text"
                            data-way-visit="nome"
                            placeholder="Nome do cliente"
                            autocomplete="off"
                        >

                    </div>


                    <!-- TELEFONE -->

                    <div class="way-visit-field">

                        <label>
                            📱 Telefone
                        </label>

                        <input
                            type="text"
                            data-way-visit="telefone"
                            placeholder="Telefone do cliente"
                            autocomplete="off"
                        >

                    </div>


                    <!-- ENDEREÇO -->

                    <div
                        class="
                            way-visit-field
                            way-visit-field-full
                        "
                    >

                        <label>
                            📍 Endereço
                        </label>

                        <input
                            type="text"
                            data-way-visit="endereco"
                            placeholder="Digite o endereço do cliente"
                            autocomplete="off"
                        >

                    </div>


                    <!-- DATA -->

                    <div class="way-visit-field">

                        <label>
                            📅 Data da visita
                        </label>

                        <input
                            type="date"
                            data-way-visit="data"
                        >

                    </div>


                    <!-- PERÍODO -->

                    <div class="way-visit-field">

                        <label>
                            🌤️ Período
                        </label>

                        <select
                            data-way-visit="periodo"
                        >

                            <option value="">
                                Selecione...
                            </option>

                            <option value="manha">
                                Manhã — 08:00 às 12:00
                            </option>

                            <option value="tarde">
                                Tarde — 13:00 às 17:00
                            </option>

                            <option value="noite">
                                Noite — 18:00 às 20:00
                            </option>

                        </select>

                    </div>


                    <!-- PROTOCOLO -->

                    <div
                        class="
                            way-visit-field
                            way-visit-field-full
                        "
                    >

                        <label>
                            🔢 Protocolo
                        </label>

                        <input
                            type="text"
                            data-way-visit="protocolo"
                            placeholder="Cole aqui o protocolo da visita"
                            autocomplete="off"
                        >

                    </div>


                    <!-- PREVIEW -->

                    <div
                        class="
                            way-visit-field
                            way-visit-field-full
                        "
                    >

                        <label>
                            📄 Pré-visualização
                        </label>

                        <textarea
                            class="way-visit-preview"
                            data-way-visit="preview"
                            readonly
                        ></textarea>

                    </div>

                </div>


                <div
                    class="way-visit-status"
                    data-way-visit="status"
                ></div>

            </div>


            <div class="way-visit-footer">

                <button
                    type="button"
                    class="way-visit-clear"
                    title="Apagar somente o rascunho deste atendimento"
                >
                    🗑 Limpar rascunho
                </button>

                <button
                    type="button"
                    class="way-visit-cancel"
                >
                    Fechar
                </button>

                <button
                    type="button"
                    class="way-visit-copy"
                >
                    📋 Copiar relatório
                </button>

            </div>

        `;


        overlay.appendChild(
            modal
        );


        document.body.appendChild(
            overlay
        );


        /* =====================================================
           CAMPOS
           ===================================================== */

        const campoNome =
            modal.querySelector(
                '[data-way-visit="nome"]'
            );


        const campoTelefone =
            modal.querySelector(
                '[data-way-visit="telefone"]'
            );


        const campoEndereco =
            modal.querySelector(
                '[data-way-visit="endereco"]'
            );


        const campoData =
            modal.querySelector(
                '[data-way-visit="data"]'
            );


        const campoPeriodo =
            modal.querySelector(
                '[data-way-visit="periodo"]'
            );


        const campoProtocolo =
            modal.querySelector(
                '[data-way-visit="protocolo"]'
            );


        const campoPreview =
            modal.querySelector(
                '[data-way-visit="preview"]'
            );


        const status =
            modal.querySelector(
                '[data-way-visit="status"]'
            );


        /* =====================================================
           PREENCHIMENTO INICIAL
           ===================================================== */

        campoNome.value =
            valoresIniciais.nome;


        campoTelefone.value =
            valoresIniciais.telefone;


        campoEndereco.value =
            valoresIniciais.endereco;


        campoData.value =
            valoresIniciais.data;


        campoPeriodo.value =
            valoresIniciais.periodo;


        campoProtocolo.value =
            valoresIniciais.protocolo;


        /* =====================================================
           DADOS DO FORMULÁRIO
           ===================================================== */

        function obterDadosFormulario() {

            return {

                nome:
                    campoNome
                        .value
                        .trim(),

                telefone:
                    campoTelefone
                        .value
                        .trim(),

                endereco:
                    campoEndereco
                        .value
                        .trim(),

                data:
                    campoData
                        .value,

                periodo:
                    campoPeriodo
                        .value,

                protocolo:
                    campoProtocolo
                        .value
                        .trim()
            };
        }


        /* =====================================================
           SALVA RASCUNHO
           ===================================================== */

        function salvarRascunhoAtual() {

            if (
                !codigoAtendimento
            ) {

                return;
            }


            salvarCacheVisita(
                codigoAtendimento,
                obterDadosFormulario()
            );
        }


        /* =====================================================
           PREVIEW
           ===================================================== */

        function atualizarPreview() {

            const dados =
                obterDadosFormulario();


            campoPreview.value =
                gerarTextoVisita(
                    dados
                );
        }


        /* =====================================================
           ALTERAÇÕES DO FORMULÁRIO
           ===================================================== */

        let timerCache =
            null;


        function campoAlterado() {

            atualizarPreview();


            /*
             * Debounce pequeno para não escrever
             * no sessionStorage a cada tecla.
             */

            clearTimeout(
                timerCache
            );


            timerCache =
                setTimeout(
                    salvarRascunhoAtual,
                    250
                );
        }


        [
            campoNome,
            campoTelefone,
            campoEndereco,
            campoData,
            campoPeriodo,
            campoProtocolo
        ]
            .forEach(
                campo => {

                    campo.addEventListener(
                        'input',
                        campoAlterado
                    );


                    campo.addEventListener(
                        'change',
                        campoAlterado
                    );
                }
            );


        atualizarPreview();


        /* =====================================================
           FECHAMENTO
           ===================================================== */

        function fecharModalSalvando() {

            /*
             * Garante que o último caractere digitado
             * também foi salvo antes de fechar.
             */

            clearTimeout(
                timerCache
            );


            salvarRascunhoAtual();


            fecharModalVisita();
        }


        modal
            .querySelector(
                '.way-visit-close'
            )
            .addEventListener(
                'click',
                fecharModalSalvando
            );


        modal
            .querySelector(
                '.way-visit-cancel'
            )
            .addEventListener(
                'click',
                fecharModalSalvando
            );


        /*
         * Clique fora NÃO fecha.
         */

        overlay.addEventListener(
            'click',

            function (
                event
            ) {

                if (
                    event.target ===
                    overlay
                ) {

                    event.preventDefault();

                    event.stopPropagation();
                }
            }
        );


        /*
         * ESC NÃO fecha.
         */

        overlay.addEventListener(
            'keydown',

            function (
                event
            ) {

                if (
                    event.key ===
                        'Escape'
                ) {

                    event.preventDefault();

                    event.stopPropagation();
                }
            },

            true
        );


        /* =====================================================
           LIMPAR RASCUNHO
           ===================================================== */

        modal
            .querySelector(
                '.way-visit-clear'
            )
            .addEventListener(
                'click',

                function () {

                    /*
                     * Só remove o cache do atendimento atual.
                     */

                    apagarCacheVisita(
                        codigoAtendimento
                    );


                    /*
                     * Volta ao estado padrão.
                     *
                     * Nome e telefone:
                     * dados atuais do cliente.
                     *
                     * Endereço:
                     * vazio.
                     *
                     * Data:
                     * hoje.
                     *
                     * Período:
                     * vazio.
                     *
                     * Protocolo:
                     * vazio.
                     */

                    campoNome.value =
                        nomeAtual;


                    campoTelefone.value =
                        telefoneAtual;


                    campoEndereco.value =
                        '';


                    campoData.value =
                        obterDataHojeInput();


                    campoPeriodo.value =
                        '';


                    campoProtocolo.value =
                        '';


                    atualizarPreview();


                    status.textContent =
                        '✓ Rascunho deste atendimento apagado.';


                    status.className =
                        'way-visit-status success';


                    campoEndereco.focus();
                }
            );


        /* =====================================================
           COPIAR RELATÓRIO
           ===================================================== */

        modal
            .querySelector(
                '.way-visit-copy'
            )
            .addEventListener(
                'click',

                async function () {

                    const dados =
                        obterDadosFormulario();


                    const faltando =
                        [];


                    if (!dados.nome) {

                        faltando.push(
                            'nome'
                        );
                    }


                    if (!dados.endereco) {

                        faltando.push(
                            'endereço'
                        );
                    }


                    if (!dados.data) {

                        faltando.push(
                            'data'
                        );
                    }


                    if (!dados.periodo) {

                        faltando.push(
                            'período'
                        );
                    }


                    if (!dados.telefone) {

                        faltando.push(
                            'telefone'
                        );
                    }


                    if (!dados.protocolo) {

                        faltando.push(
                            'protocolo'
                        );
                    }


                    if (
                        faltando.length
                    ) {

                        status.textContent =
                            '⚠️ Preencha: ' +
                            faltando.join(
                                ', '
                            ) +
                            '.';


                        status.className =
                            'way-visit-status error';


                        return;
                    }


                    /*
                     * Salva antes de copiar.
                     */

                    salvarRascunhoAtual();


                    const texto =
                        gerarTextoVisita(
                            dados
                        );


                    const sucesso =
                        await copiarTextoSimples(
                            texto
                        );


                    if (
                        sucesso
                    ) {

                        status.textContent =
                            '✓ Relatório copiado. Rascunho deste atendimento mantido.';


                        status.className =
                            'way-visit-status success';


                        const botao =
                            modal.querySelector(
                                '.way-visit-copy'
                            );


                        const original =
                            botao.innerHTML;


                        botao.innerHTML =
                            '✓ Copiado';


                        setTimeout(
                            function () {

                                botao.innerHTML =
                                    original;
                            },

                            1200
                        );

                    } else {

                        status.textContent =
                            'Não foi possível copiar o relatório.';


                        status.className =
                            'way-visit-status error';
                    }
                }
            );


        /* =====================================================
           FOCO INICIAL
           ===================================================== */

        setTimeout(
            function () {

                /*
                 * Se já existe rascunho,
                 * não força o endereço.
                 *
                 * Se é primeira abertura e endereço
                 * está vazio, deixa o cursor nele.
                 */

                if (
                    !campoEndereco.value
                ) {

                    campoEndereco.focus();

                } else if (
                    !campoPeriodo.value
                ) {

                    campoPeriodo.focus();

                } else if (
                    !campoProtocolo.value
                ) {

                    campoProtocolo.focus();
                }
            },

            50
        );
    }


    /* =========================================================
       ITEM DO RESUMO
       ========================================================= */

    function criarItemResumo(
        tipo,
        emoji,
        label
    ) {

        const item =
            document.createElement(
                'div'
            );


        item.className =
            'way-summary-item';


        item.dataset.wayKey =
            tipo;


        const icone =
            document.createElement(
                'span'
            );


        icone.className =
            'way-summary-icon';


        icone.textContent =
            emoji;


        const rotulo =
            document.createElement(
                'span'
            );


        rotulo.className =
            'way-summary-label';


        rotulo.textContent =
            label + ':';


        const valor =
            document.createElement(
                'span'
            );


        valor.className =
            'way-summary-value';


        valor.dataset.wayValue =
            tipo;


        valor.textContent =
            '—';


        const copiar =
            document.createElement(
                'button'
            );


        copiar.type =
            'button';


        copiar.className =
            'way-summary-copy';


        copiar.dataset.wayCopy =
            tipo;


        copiar.innerHTML =
            '📋';


        copiar.title =
            'Copiar ' +
            label.toLowerCase();


        item.append(
            icone,
            rotulo,
            valor,
            copiar
        );


        return item;
    }


    /* =========================================================
       CRIA RESUMO
       ========================================================= */

    function criarResumoCliente(
        cabecalho
    ) {

        const resumo =
            document.createElement(
                'div'
            );


        resumo.className =
            'way-customer-summary';


        resumo.appendChild(
            criarItemResumo(
                'nome',
                '👤',
                'Nome'
            )
        );


        resumo.appendChild(
            criarItemResumo(
                'telefone',
                '📱',
                'Telefone'
            )
        );


        resumo.appendChild(
            criarItemResumo(
                'protocolo',
                '🎫',
                'Protocolo'
            )
        );


        /* =====================================================
           AÇÕES
           ===================================================== */

        const acoes =
            document.createElement(
                'div'
            );


        acoes.className =
            'way-summary-actions';


        const visitaTecnica =
            document.createElement(
                'button'
            );


        visitaTecnica.type =
            'button';


        visitaTecnica.className =
            'way-technical-visit';


        visitaTecnica.innerHTML =
            '🛠 Visita Técnica';


        visitaTecnica.title =
            'Gerar relatório de visita técnica';


        const copiarTudo =
            document.createElement(
                'button'
            );


        copiarTudo.type =
            'button';


        copiarTudo.className =
            'way-copy-all';


        copiarTudo.innerHTML =
            '📋 Copiar tudo';


        copiarTudo.title =
            'Copiar nome, telefone e protocolo';


        acoes.append(
            visitaTecnica,
            copiarTudo
        );


        resumo.appendChild(
            acoes
        );


        /* =====================================================
           VISITA
           ===================================================== */

        visitaTecnica.addEventListener(
            'click',

            function (
                event
            ) {

                event.preventDefault();

                event.stopPropagation();


                abrirModalVisita(
                    cabecalho,
                    resumo
                );
            }
        );


        /* =====================================================
           CÓPIA
           ===================================================== */

        resumo.addEventListener(
            'click',

            async function (
                event
            ) {

                const botaoIndividual =
                    event.target.closest(
                        '[data-way-copy]'
                    );


                if (
                    botaoIndividual
                ) {

                    event.preventDefault();

                    event.stopPropagation();


                    const tipo =
                        botaoIndividual
                            .dataset
                            .wayCopy;


                    const valorElemento =
                        resumo.querySelector(
                            `[data-way-value="${tipo}"]`
                        );


                    if (
                        !valorElemento
                    ) {

                        return;
                    }


                    const valor =
                        valorElemento
                            .textContent
                            .trim();


                    if (
                        !valor ||
                        valor === '—'
                    ) {

                        return;
                    }


                    let emoji =
                        '';

                    let label =
                        '';


                    if (
                        tipo ===
                        'nome'
                    ) {

                        emoji =
                            '👤';

                        label =
                            'Nome';

                    } else if (
                        tipo ===
                        'telefone'
                    ) {

                        emoji =
                            '📱';

                        label =
                            'Telefone';

                    } else if (
                        tipo ===
                        'protocolo'
                    ) {

                        emoji =
                            '🎫';

                        label =
                            'Protocolo';

                    } else {

                        return;
                    }


                    const textoPlano =
                        `${emoji} ${label}: ${valor}`;


                    const html =
                        `${emoji} <strong>${label}:</strong> ${escaparHTML(valor)}`;


                    const sucesso =
                        await copiarConteudoRico(
                            textoPlano,
                            html
                        );


                    if (
                        sucesso
                    ) {

                        mostrarFeedbackCopia(
                            botaoIndividual
                        );
                    }


                    return;
                }


                /* =================================================
                   COPIAR TUDO
                   ================================================= */

                const botaoTudo =
                    event.target.closest(
                        '.way-copy-all'
                    );


                if (
                    !botaoTudo
                ) {

                    return;
                }


                event.preventDefault();

                event.stopPropagation();


                const nome =
                    resumo.querySelector(
                        '[data-way-value="nome"]'
                    )
                        ?.textContent
                        .trim()
                    ||
                    '—';


                const telefone =
                    resumo.querySelector(
                        '[data-way-value="telefone"]'
                    )
                        ?.textContent
                        .trim()
                    ||
                    '—';


                const protocolo =
                    resumo.querySelector(
                        '[data-way-value="protocolo"]'
                    )
                        ?.textContent
                        .trim()
                    ||
                    '—';


                const textoPlano =
`👤 Nome: ${nome}
📱 Telefone: ${telefone}
🎫 Protocolo: ${protocolo}`;


                const html =
`<div>👤 <strong>Nome:</strong> ${escaparHTML(nome)}</div>
<div>📱 <strong>Telefone:</strong> ${escaparHTML(telefone)}</div>
<div>🎫 <strong>Protocolo:</strong> ${escaparHTML(protocolo)}</div>`;


                const sucesso =
                    await copiarConteudoRico(
                        textoPlano,
                        html
                    );


                if (
                    sucesso
                ) {

                    const original =
                        botaoTudo.innerHTML;


                    botaoTudo.innerHTML =
                        '✓ Copiado';


                    setTimeout(
                        function () {

                            botaoTudo.innerHTML =
                                original;
                        },

                        1000
                    );
                }
            }
        );


        const row =
            cabecalho.querySelector(
                ':scope > .row'
            );


        if (
            row
        ) {

            cabecalho.insertBefore(
                resumo,
                row
            );

        } else {

            cabecalho.appendChild(
                resumo
            );
        }


        return resumo;
    }


    /* =========================================================
       CONFIGURA RESUMO
       ========================================================= */

    function configurarResumoCliente(
        cabecalho
    ) {

        if (
            !CONFIG.exibirResumoCliente ||
            !cabecalho
        ) {

            return;
        }


        const nome =
            limparNomeCliente(
                extrairValorCampo(
                    cabecalho,
                    '.contato-nome',
                    /^Nome:\s*/i
                )
            );


        const telefone =
            formatarTelefone(
                extrairValorCampo(
                    cabecalho,
                    '.contato-telefone',
                    /^Telefone:\s*/i
                )
            );


        const protocolo =
            extrairValorCampo(
                cabecalho,
                '.atendimento-protocolo',
                /^(Número de protocolo|Protocolo):\s*/i
            );


        let resumo =
            cabecalho.querySelector(
                ':scope > .way-customer-summary'
            );


        if (
            !resumo
        ) {

            resumo =
                criarResumoCliente(
                    cabecalho
                );
        }


        const campoNome =
            resumo.querySelector(
                '[data-way-value="nome"]'
            );


        const campoTelefone =
            resumo.querySelector(
                '[data-way-value="telefone"]'
            );


        const campoProtocolo =
            resumo.querySelector(
                '[data-way-value="protocolo"]'
            );


        if (
            campoNome
        ) {

            campoNome.textContent =
                nome ||
                '—';
        }


        if (
            campoTelefone
        ) {

            campoTelefone.textContent =
                telefone ||
                '—';
        }


        if (
            campoProtocolo
        ) {

            campoProtocolo.textContent =
                protocolo ||
                '—';
        }


        cabecalho
            .querySelector(
                '.contato-nome'
            )
            ?.classList.add(
                'way-resumo-original-oculto'
            );


        cabecalho
            .querySelector(
                '.contato-telefone'
            )
            ?.classList.add(
                'way-resumo-original-oculto'
            );


        cabecalho
            .querySelector(
                '.atendimento-protocolo'
            )
            ?.classList.add(
                'way-resumo-original-oculto'
            );
    }


    /* =========================================================
       RODAPÉ
       ========================================================= */

    function removerRodape(
        contexto = document
    ) {

        if (
            !CONFIG.removerImagemRodape
        ) {

            return;
        }


        contexto
            .querySelectorAll?.(
                SELETOR_RODAPE
            )
            .forEach(
                imagem => {

                    imagem.remove();
                }
            );
    }


    /* =========================================================
       TAGS
       ========================================================= */

    function definirEstadoTags(
        tags,
        botao,
        mostrar
    ) {

        if (
            mostrar
        ) {

            tags.classList.remove(
                'way-tags-ocultas'
            );


            botao.innerHTML =
                '🏷 Ocultar tags';


            botao.classList.add(
                'way-tags-abertas'
            );

        } else {

            tags.classList.add(
                'way-tags-ocultas'
            );


            botao.innerHTML =
                '🏷 Mostrar tags';


            botao.classList.remove(
                'way-tags-abertas'
            );
        }
    }


    /* =========================================================
       CABEÇALHO
       ========================================================= */

    function configurarCabecalho(
        cabecalho
    ) {

        if (!cabecalho) {
            return;
        }


        configurarResumoCliente(
            cabecalho
        );


        const tags =
            cabecalho.querySelector(
                CLASSE_TAGS
            );


        if (!tags) {
            return;
        }


        if (
            cabecalho.querySelector(
                ':scope > .way-toggle-tags'
            )
        ) {

            return;
        }


        if (
            CONFIG.ocultarTags
        ) {

            tags.classList.add(
                'way-tags-ocultas'
            );
        }


        const botao =
            document.createElement(
                'button'
            );


        botao.type =
            'button';


        botao.className =
            'way-toggle-tags';


        botao.innerHTML =
            '🏷 Mostrar tags';


        botao.addEventListener(
            'click',

            function (
                event
            ) {

                event.preventDefault();

                event.stopPropagation();


                definirEstadoTags(
                    tags,
                    botao,
                    tags.classList.contains(
                        'way-tags-ocultas'
                    )
                );
            }
        );


        cabecalho.insertBefore(
            botao,
            cabecalho.firstChild
        );
    }


    /* =========================================================
       COMPACTA BOTTOM
       ========================================================= */

    function compactarBottom(
        contexto = document
    ) {

        contexto
            .querySelectorAll?.(
                SELETOR_ACOES
            )
            .forEach(
                toolbar => {

                    if (
                        toolbar.dataset
                            .wayCompacta ===
                            'true'
                    ) {

                        return;
                    }


                    toolbar.dataset
                        .wayCompacta =
                        'true';


                    const anterior =
                        toolbar
                            .previousElementSibling;


                    if (
                        anterior &&
                        anterior.tagName ===
                            'BR'
                    ) {

                        anterior
                            .classList
                            .add(
                                'way-gap-acoes'
                            );
                    }
                }
            );
    }


    /* =========================================================
       ABAS
       ========================================================= */

    function restaurarEstruturaAbas() {

        const tabs =
            document.querySelector(
                SELETOR_ABAS
            );


        const abas =
            document.querySelector(
                SELETOR_CONTEUDO_ABAS
            );


        if (
            !tabs ||
            !abas
        ) {

            return null;
        }


        const container =
            abas.parentElement;


        if (!container) {

            return null;
        }


        if (
            tabs.parentElement !==
                container ||
            tabs.nextElementSibling !==
                abas
        ) {

            container.insertBefore(
                tabs,
                abas
            );
        }


        document
            .getElementById(
                'way-tabs-placeholder'
            )
            ?.remove();


        return {
            tabs,
            abas,
            container
        };
    }


    function aplicarPosicaoAbas() {

        const estrutura =
            restaurarEstruturaAbas();


        if (!estrutura) {

            return;
        }


        const {
            tabs,
            abas,
            container
        } = estrutura;


        const tabbable =
            container
                .classList
                .contains(
                    'tabbable'
                )
                ?
                container
                :
                abas.closest(
                    '.tabbable'
                );


        if (!tabbable) {

            return;
        }


        if (
            POSICAO_ABAS ===
                'baixo'
        ) {

            tabbable
                .classList
                .add(
                    'way-layout-tabs-bottom'
                );


            tabs
                .classList
                .add(
                    'way-tabs-bottom'
                );

        } else {

            tabbable
                .classList
                .remove(
                    'way-layout-tabs-bottom'
                );


            tabs
                .classList
                .remove(
                    'way-tabs-bottom'
                );
        }
    }


    function definirPosicaoAbas(
        posicao
    ) {

        POSICAO_ABAS =
            posicao;


        GM_setValue(
            STORAGE_POSICAO_ABAS,
            posicao
        );


        aplicarPosicaoAbas();
    }


    /* =========================================================
       MENU
       ========================================================= */

    function criarMenuTampermonkey() {

        GM_registerMenuCommand(
            '⬆ Abas no topo',

            () =>

                definirPosicaoAbas(
                    'topo'
                )
        );


        GM_registerMenuCommand(
            '⬇ Abas embaixo',

            () =>

                definirPosicaoAbas(
                    'baixo'
                )
        );
    }


    /* =========================================================
       CONFIGURA TUDO
       ========================================================= */

    function configurarTodos() {

        document
            .querySelectorAll(
                CLASSE_CABECALHO
            )
            .forEach(
                configurarCabecalho
            );


        removerRodape();


        compactarBottom();


        aplicarPosicaoAbas();
    }


    /* =========================================================
       OBSERVER
       ========================================================= */

    function iniciarObserver() {

        let agendado =
            false;


        function atualizar() {

            if (
                agendado
            ) {

                return;
            }


            agendado =
                true;


            requestAnimationFrame(
                function () {

                    agendado =
                        false;


                    configurarTodos();
                }
            );
        }


        const observer =
            new MutationObserver(
                atualizar
            );


        observer.observe(
            document.documentElement,
            {
                childList: true,
                subtree: true,
                characterData: true
            }
        );
    }


    /* =========================================================
       ALT + T
       ========================================================= */

    document.addEventListener(
        'keydown',

        function (
            event
        ) {

            if (
                !event.altKey ||
                event.key
                    .toLowerCase() !==
                    't'
            ) {

                return;
            }


            event.preventDefault();


            const conversa =
                Array
                    .from(
                        document
                            .querySelectorAll(
                                '.conversa'
                            )
                    )
                    .find(
                        elemento =>
                            elemento
                                .offsetParent !==
                            null
                    );


            if (!conversa) {

                return;
            }


            const tags =
                conversa.querySelector(
                    CLASSE_TAGS
                );


            const botao =
                conversa.querySelector(
                    '.way-toggle-tags'
                );


            if (
                !tags ||
                !botao
            ) {

                return;
            }


            definirEstadoTags(
                tags,
                botao,
                tags
                    .classList
                    .contains(
                        'way-tags-ocultas'
                    )
            );
        },

        true
    );


    /* =========================================================
       ALT + B
       ========================================================= */

    document.addEventListener(
        'keydown',

        function (
            event
        ) {

            if (
                !event.altKey ||
                event.key
                    .toLowerCase() !==
                    'b'
            ) {

                return;
            }


            event.preventDefault();


            definirPosicaoAbas(
                POSICAO_ABAS ===
                    'topo'
                    ?
                    'baixo'
                    :
                    'topo'
            );
        },

        true
    );


    /* =========================================================
       INICIALIZAÇÃO
       ========================================================= */

    function iniciar() {

        adicionarCSS();


        criarMenuTampermonkey();


        configurarTodos();


        iniciarObserver();


        setInterval(
            configurarTodos,
            2500
        );


        console.log(
            '[Way Interface] Interface Compacta 3.4 ativa.'
        );


        console.log(
            '[Way Interface] Rascunho de Visita Técnica isolado por código de atendimento.'
        );


        console.log(
            '[Way Interface] Cache de visita usa somente sessionStorage.'
        );
    }


    if (
        document.documentElement
    ) {

        iniciar();

    } else {

        document.addEventListener(
            'DOMContentLoaded',
            iniciar
        );
    }

})();

});

"use strict";

const IA_NOCO_DB_ORIGIN = "https://ia-nocodb.internetway.com.br";
const MESSAGE_TYPE = "wayTools:iaMessageNotification";
const DESTINATION_PREFIX = "wayTools.notificationDestination.";
const recentFingerprints = new Map();
const DEDUPLICATION_WINDOW_MS = 60_000;

function normalizeText(value, maximumLength) {
  const normalized = String(value ?? "")
    .replace(/\s+/g, " ")
    .trim();

  if (!maximumLength || normalized.length <= maximumLength) {
    return normalized;
  }

  return `${normalized.slice(0, Math.max(1, maximumLength - 1)).trimEnd()}…`;
}

function hashText(value) {
  let hash = 2166136261;

  for (const character of String(value)) {
    hash ^= character.codePointAt(0);
    hash = Math.imul(hash, 16777619);
  }

  return (hash >>> 0).toString(36);
}

function isTrustedSender(sender) {
  try {
    return new URL(sender?.url || "").origin === IA_NOCO_DB_ORIGIN;
  } catch {
    return false;
  }
}

function clearExpiredFingerprints(now) {
  for (const [fingerprint, createdAt] of recentFingerprints) {
    if (now - createdAt > DEDUPLICATION_WINDOW_MS) {
      recentFingerprints.delete(fingerprint);
    }
  }
}

function storeDestination(notificationId, sender, url) {
  return chrome.storage.session.set({
    [`${DESTINATION_PREFIX}${notificationId}`]: {
      tabId: sender?.tab?.id,
      url: normalizeText(url, 2_000)
    }
  });
}

function createNotification(message, sender, sendResponse) {
  if (!isTrustedSender(sender)) {
    sendResponse({ ok: false, error: "Origem não autorizada." });
    return;
  }

  const now = Date.now();
  const fingerprint = normalizeText(message.fingerprint, 500);

  clearExpiredFingerprints(now);

  if (!fingerprint || recentFingerprints.has(fingerprint)) {
    sendResponse({ ok: true, duplicate: true });
    return;
  }

  recentFingerprints.set(fingerprint, now);

  const conversationKey = normalizeText(message.conversationKey, 200) || fingerprint;
  const notificationId = `way-tools-ia-${hashText(conversationKey)}`;
  const customerName = normalizeText(message.customerName, 80) || "Cliente";
  const preview = normalizeText(message.preview, 220) || "Nova mensagem recebida.";
  const destinationUrl = normalizeText(message.url, 2_000) || sender.url;

  chrome.notifications.create(
    notificationId,
    {
      type: "basic",
      iconUrl: chrome.runtime.getURL("128.png"),
      title: `Nova mensagem — ${customerName}`,
      message: preview,
      contextMessage: "Way Tools • IA NocoDB",
      priority: 2,
      requireInteraction: true,
      silent: false
    },
    (createdId) => {
      const error = chrome.runtime.lastError;

      if (error) {
        recentFingerprints.delete(fingerprint);
        sendResponse({ ok: false, error: error.message });
        return;
      }

      storeDestination(createdId || notificationId, sender, destinationUrl)
        .catch(() => undefined)
        .finally(() => sendResponse({ ok: true, notificationId: createdId || notificationId }));
    }
  );
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== MESSAGE_TYPE) {
    return false;
  }

  createNotification(message, sender, sendResponse);
  return true;
});

async function focusNotificationDestination(notificationId) {
  const storageKey = `${DESTINATION_PREFIX}${notificationId}`;
  const stored = await chrome.storage.session.get(storageKey);
  const destination = stored[storageKey];

  if (!destination) {
    return;
  }

  if (Number.isInteger(destination.tabId)) {
    try {
      const tab = await chrome.tabs.get(destination.tabId);
      await chrome.tabs.update(destination.tabId, { active: true });

      if (Number.isInteger(tab.windowId)) {
        await chrome.windows.update(tab.windowId, { focused: true });
      }

      return;
    } catch {
      // A aba pode ter sido fechada desde a criação da notificação.
    }
  }

  if (destination.url.startsWith(`${IA_NOCO_DB_ORIGIN}/`)) {
    await chrome.tabs.create({ url: destination.url });
  }
}

chrome.notifications.onClicked.addListener((notificationId) => {
  focusNotificationDestination(notificationId).catch(() => undefined);
  chrome.notifications.clear(notificationId, () => void chrome.runtime.lastError);
});

chrome.notifications.onClosed.addListener((notificationId) => {
  chrome.storage.session
    .remove(`${DESTINATION_PREFIX}${notificationId}`)
    .catch(() => undefined);
});

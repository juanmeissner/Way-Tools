(() => {
  "use strict";

  let openReportGenerator = null;

  globalThis.WayToolsRuntime = {
    run(_scriptId, start) {
      start();
    },

    registerMenuCommand(scriptId, _label, callback) {
      if (scriptId === "way-erp-gerador-relato") {
        openReportGenerator = callback;
        window.setTimeout(() => callback(), 0);
      }

      return `${scriptId}:developer-preview`;
    }
  };

  document.addEventListener("DOMContentLoaded", () => {
    const reopenButton = document.querySelector("#reopen-generator");
    const editor = document.querySelector("#preview-editor");
    const status = document.querySelector("#preview-status");

    reopenButton.addEventListener("click", () => {
      if (typeof openReportGenerator === "function") {
        openReportGenerator();
      }
    });

    editor.addEventListener("input", () => {
      status.textContent = "Relato inserido no campo de teste. Nenhum dado foi enviado ao ERP.";
      status.classList.add("success");
    });
  }, { once: true });
})();

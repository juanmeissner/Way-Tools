(() => {
  "use strict";

  const catalogElement = document.querySelector("#catalog");
  const summaryElement = document.querySelector("#summary");
  const noticeElement = document.querySelector("#notice");
  const firstPackageOnly = document.querySelector("#first-package-only");
  const downloadButton = document.querySelector("#download-draft");
  let draft = null;

  function draftText(command) {
    if (command.type === "time_variant") {
      return `Manhã: ${command.morning}\n\nTarde: ${command.afternoon}\n\nNoite: ${command.night}`;
    }
    return command.text || "Texto ainda não elaborado.";
  }

  function render() {
    const onlyFirst = firstPackageOnly.checked;
    const categories = draft.categories
      .map((category) => ({ ...category, commands: category.commands.filter((command) => !onlyFirst || command.firstPackage) }))
      .filter((category) => category.commands.length > 0);
    const total = draft.categories.flatMap((category) => category.commands).length;
    const firstTotal = draft.recommendedFirstPackage.length;
    summaryElement.textContent = `${firstTotal} no primeiro pacote · ${total} comandos planejados`;
    catalogElement.replaceChildren(...categories.map((category) => {
      const article = document.createElement("article");
      article.className = "category";
      const title = document.createElement("h2");
      title.textContent = category.label;
      const commands = document.createElement("div");
      commands.className = "commands";
      commands.replaceChildren(...category.commands.map((command) => {
        const item = document.createElement("article");
        item.className = "command";
        const identity = document.createElement("div");
        const code = document.createElement("code");
        code.textContent = `!${command.command}`;
        const badge = document.createElement("span");
        badge.className = "badge";
        badge.textContent = command.status === "aguardando_aprovacao" ? "AGUARDANDO APROVAÇÃO" : "PLANEJADO";
        const target = document.createElement("small");
        target.textContent = `Categoria final: ${command.targetCategory}`;
        identity.append(code, badge, target);
        const detail = document.createElement("div");
        const strong = document.createElement("strong");
        strong.textContent = command.title;
        const text = document.createElement("p");
        text.textContent = draftText(command);
        detail.append(strong, text);
        item.append(identity, detail);
        return item;
      }));
      article.append(title, commands);
      return article;
    }));
  }

  function downloadDraft() {
    const url = URL.createObjectURL(new Blob([`${JSON.stringify(draft, null, 2)}\n`], { type: "application/json" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "way-tools-catalogo-sac-rascunho.json";
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  fetch(chrome.runtime.getURL("data/mensagens-sac-rascunho.json"))
    .then((response) => {
      if (!response.ok) throw new Error("Não foi possível carregar o catálogo.");
      return response.json();
    })
    .then((value) => {
      draft = value;
      noticeElement.textContent = draft.notice;
      render();
    })
    .catch((error) => {
      catalogElement.textContent = error.message;
      summaryElement.textContent = "Falha ao carregar";
    });

  firstPackageOnly.addEventListener("change", () => draft && render());
  downloadButton.addEventListener("click", () => draft && downloadDraft());
})();
